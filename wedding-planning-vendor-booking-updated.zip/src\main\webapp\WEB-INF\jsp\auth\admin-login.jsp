<%@ include file="../partials/header.jspf" %>
<main class="container page-shell">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card p-4">
                <h2 class="h4 mb-3">Admin Login</h2>
                <div class="admin-login-logo mb-3">
                    <span>The</span>
                    <strong>Group 107</strong>
                    <small>Admin Studio</small>
                </div>
                <c:if test="${not empty error}"><div class="alert alert-danger">${error}</div></c:if>
                <form method="post" action="/admin/login">
                    <div class="mb-3"><label class="form-label">Email</label><input class="form-control" name="email" type="email" required></div>
                    <div class="mb-3"><label class="form-label">Password</label><input class="form-control" name="password" type="password" required></div>
                    <button class="btn btn-primary w-100">Enter Admin Panel</button>
                </form>
                <p class="text-muted small mt-3 mb-0">Demo access: use any email and any password.</p>
            </div>
        </div>
    </div>
</main>
<%@ include file="../partials/footer.jspf" %>
