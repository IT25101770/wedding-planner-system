<%@ include file="../partials/header.jspf" %>
<main class="container page-shell">
    <div class="card p-4">
        <h1 class="h4 mb-3">Payment</h1>
        <form method="post" action="/payments" class="row g-3">
            <input type="hidden" name="id" value="${payment.id}">
            <div class="col-md-4">
                <label class="form-label">Booking</label>
                <select class="form-select" name="bookingId" required>
                    <c:forEach items="${bookings}" var="booking"><option value="${booking.id}" ${payment.bookingId == booking.id ? 'selected' : ''}>${booking.id} - ${booking.vendorId}</option></c:forEach>
                </select>
            </div>
            <div class="col-md-4"><label class="form-label">Amount</label><input class="form-control" id="amount" name="amount" type="number" step="0.01" value="${payment.amount}" required></div>
            <div class="col-md-4">
                <label class="form-label">Discount Package</label>
                <select class="form-select" id="discountPackage">
                    <option value="0">No package</option>
                    <option value="15">Half Package - 15%</option>
                    <option value="20">Full Package - 20%</option>
                    <option value="10">Day Package - 10%</option>
                </select>
            </div>
            <div class="col-md-4"><label class="form-label">Discount %</label><input class="form-control" id="discountPercent" name="discountPercent" type="number" step="0.01" value="${payment.discountPercent}"></div>
            <div class="col-md-4"><label class="form-label">Invoice Total</label><input class="form-control" id="invoiceTotal" type="text" readonly></div>
            <div class="col-md-6"><label class="form-label">Status</label><select class="form-select" name="status"><option ${payment.status == 'Paid' ? 'selected' : ''}>Paid</option><option ${payment.status == 'Unpaid' ? 'selected' : ''}>Unpaid</option></select></div>
            <div class="col-md-6"><label class="form-label">Paid Date</label><input class="form-control" name="paidDate" type="date" value="${payment.paidDate}"></div>
            <div class="col-12"><button class="btn btn-primary">Save Payment</button><a class="btn btn-outline-secondary" href="/payments">Cancel</a></div>
        </form>
    </div>
</main>
<script>
    const params = new URLSearchParams(window.location.search);
    const packageMap = { half: "15", full: "20", day: "10" };
    const packageSelect = document.getElementById("discountPackage");
    const discountInput = document.getElementById("discountPercent");
    const amountInput = document.getElementById("amount");
    const totalInput = document.getElementById("invoiceTotal");

    function updateTotal() {
        const amount = parseFloat(amountInput.value || "0");
        const discount = parseFloat(discountInput.value || "0");
        const total = amount - (amount * discount / 100);
        totalInput.value = "Rs. " + total.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }

    packageSelect.addEventListener("change", function () {
        discountInput.value = this.value;
        updateTotal();
    });
    discountInput.addEventListener("input", updateTotal);
    amountInput.addEventListener("input", updateTotal);

    const selectedPackage = packageMap[params.get("package")];
    if (selectedPackage) {
        packageSelect.value = selectedPackage;
        discountInput.value = selectedPackage;
    }
    updateTotal();
</script>
<%@ include file="../partials/footer.jspf" %>
