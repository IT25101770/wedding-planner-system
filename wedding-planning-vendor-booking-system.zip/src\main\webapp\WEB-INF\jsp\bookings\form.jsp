<%@ include file="../partials/header.jspf" %>
<main class="container page-shell">
    <div class="card p-4">
        <h1 class="h4 mb-3">Book a Vendor</h1>
        <form method="post" action="/bookings" class="row g-3">
            <div class="col-md-6">
                <label class="form-label">Wedding Event</label>
                <select class="form-select" name="eventId" required>
                    <c:forEach items="${events}" var="event"><option value="${event.id}">${event.date} - ${event.venue}</option></c:forEach>
                </select>
            </div>
            <div class="col-md-6">
                <label class="form-label">Vendor</label>
                <select class="form-select" name="vendorId" required>
                    <c:forEach items="${vendors}" var="vendor"><option value="${vendor.id}">${vendor.name} - ${vendor.category}</option></c:forEach>
                </select>
            </div>
            <div class="col-md-6"><label class="form-label">Status</label><select class="form-select" name="status"><option>Pending</option><option>Confirmed</option></select></div>
            <div class="col-12"><button class="btn btn-primary">Save Booking</button><a class="btn btn-outline-secondary" href="/bookings">Cancel</a></div>
        </form>
    </div>
</main>
<%@ include file="../partials/footer.jspf" %>
