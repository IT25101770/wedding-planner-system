<%@ include file="../partials/header.jspf" %>
<main class="container page-shell">
    <div class="row justify-content-center">
        <div class="col-md-7">
            <div class="card p-4">
                <h2 class="h4 mb-3">Customer Registration</h2>
                <form method="post" action="/register" class="row g-3">
                    <div class="col-md-6"><label class="form-label">Name</label><input class="form-control" name="name" required></div>
                    <div class="col-md-6"><label class="form-label">Phone</label><input class="form-control" name="phone" required></div>
                    <div class="col-md-6"><label class="form-label">Email</label><input class="form-control" name="email" type="email" required></div>
                    <div class="col-md-6"><label class="form-label">Password</label><input class="form-control" name="password" type="password" required></div>
                    <div class="col-12"><label class="form-label">Address</label><input class="form-control" name="address" required></div>
                    <div class="col-12"><button class="btn btn-primary">Register</button></div>
                </form>
            </div>
        </div>
    </div>
</main>
<%@ include file="../partials/footer.jspf" %>
