<%@ include file="../partials/header.jspf" %>
<main class="container page-shell">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card p-4">
                <h2 class="h4 mb-3">Customer Login</h2>
                <c:if test="${not empty error}"><div class="alert alert-danger">${error}</div></c:if>
                <form method="post" action="/user/login">
                    <div class="mb-3"><label class="form-label">Email</label><input class="form-control" name="email" type="email" required></div>
                    <div class="mb-3"><label class="form-label">Password</label><input class="form-control" name="password" type="password" required></div>
                    <button class="btn btn-primary w-100">Login</button>
                </form>
                <a class="d-block mt-3" href="/register">New customer? Register</a>
            </div>
        </div>
    </div>
</main>
<%@ include file="../partials/footer.jspf" %>
