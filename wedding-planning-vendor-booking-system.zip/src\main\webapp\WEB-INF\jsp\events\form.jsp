<%@ include file="../partials/header.jspf" %>
<main class="container page-shell">
    <div class="card p-4">
        <h1 class="h4 mb-3">Wedding Event</h1>
        <form method="post" action="/events" class="row g-3">
            <input type="hidden" name="id" value="${event.id}">
            <input type="hidden" name="customerId" value="${event.customerId}">
            <div class="col-md-4"><label class="form-label">Date</label><input class="form-control" name="date" type="date" value="${event.date}" required></div>
            <div class="col-md-4"><label class="form-label">Venue</label><input class="form-control" name="venue" value="${event.venue}" required></div>
            <div class="col-md-4"><label class="form-label">Guest Count</label><input class="form-control" name="guestCount" type="number" min="1" value="${event.guestCount}" required></div>
            <div class="col-md-12"><label class="form-label">Theme</label><input class="form-control" name="theme" value="${event.theme}" required></div>
            <div class="col-12"><button class="btn btn-primary">Save Event</button><a class="btn btn-outline-secondary" href="/events">Cancel</a></div>
        </form>
    </div>
</main>
<%@ include file="../partials/footer.jspf" %>
